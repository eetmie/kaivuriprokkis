"""Inverse kinematics convergence tests across all solver methods.

For each of pinv, svd, trans, dls we confirm that iteratively applying
IKController.compute() drives the end-effector toward a Cartesian target.
We also exercise joint-limit avoidance, velocity limiting, and the
base-frame transform flag.
"""

import math
import sys
import unittest
from pathlib import Path

import numpy as np

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.append(str(ROOT_DIR))

from modules.differential_ik import IKController  # noqa: E402
from modules.excavator_ik_utils import compute_relative_joint_angles  # noqa: E402

from tests.common_kinematics import (  # noqa: E402
    build_absolute_quaternions,
    fk_from_angles,
    load_robot_config,
    make_ik_config,
    simulate_ik,
)


# Tolerance used for near-pose convergence in deep iteration simulations.
POSITION_TOL_M = 3e-3


class IKConvergenceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rc = load_robot_config()

    def _nominal_start_angles(self) -> np.ndarray:
        return np.array([0.0, math.radians(-45.0), math.radians(30.0), 0.0], dtype=np.float32)

    def _run_method(self, method: str, offset: np.ndarray, max_iters: int = 800):
        ik_params = {
            "k_val": 0.5 if method != "trans" else 0.05,
            "min_singular_value": 1e-4,
            "lambda_val": 0.02,
        }
        cfg = make_ik_config(method=method, ik_params=ik_params,
                             enable_velocity_limiting=False)
        ik = IKController(cfg, self.rc, verbose=False, default_dt=0.005)

        start = self._nominal_start_angles()
        start_pos, _ = fk_from_angles(start, self.rc)
        target = start_pos + np.asarray(offset, dtype=np.float32)
        result = simulate_ik(self.rc, ik, start, target,
                             max_iters=max_iters, pos_tol=POSITION_TOL_M, dt=0.005)
        return result, target

    def test_pinv_converges(self):
        result, target = self._run_method("pinv", [0.02, 0.01, -0.01])
        self.assertTrue(result["converged"],
                        msg=f"pinv final err={result['pos_error']:.4f} pos={result['final_pos']} target={target}")

    def test_svd_converges(self):
        result, target = self._run_method("svd", [0.02, 0.01, -0.01])
        self.assertTrue(result["converged"],
                        msg=f"svd final err={result['pos_error']:.4f}")

    def test_transpose_converges(self):
        # Jacobian-transpose with smaller gain needs more iterations.
        result, target = self._run_method("trans", [0.015, 0.005, -0.01], max_iters=4000)
        self.assertTrue(result["converged"],
                        msg=f"trans final err={result['pos_error']:.4f}")

    def test_dls_converges(self):
        result, target = self._run_method("dls", [0.02, 0.01, -0.015])
        self.assertTrue(result["converged"],
                        msg=f"dls final err={result['pos_error']:.4f}")


class IKFeatureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rc = load_robot_config()

    def test_velocity_limit_bounds_per_iteration_delta(self):
        """Per-cycle joint delta must not exceed the configured max_joint_velocities."""
        max_rad_per_iter = [0.02, 0.02, 0.02, 0.02]
        cfg = make_ik_config(method="dls",
                             enable_velocity_limiting=True,
                             max_joint_velocities=max_rad_per_iter,
                             ik_params={"k_val": 1.0, "min_singular_value": 1e-4, "lambda_val": 0.02})
        ik = IKController(cfg, self.rc, verbose=False, default_dt=0.005)

        angles = np.array([0.0, math.radians(-45.0), math.radians(30.0), 0.0], dtype=np.float32)
        start_pos, _ = fk_from_angles(angles, self.rc)
        # Large target to saturate the velocity limiter.
        target = start_pos + np.array([0.4, 0.3, -0.3], dtype=np.float32)

        from modules.quaternion_math import quat_from_axis_angle
        ik.ee_pos_des = target.astype(np.float32)
        ik.ee_quat_des = quat_from_axis_angle(np.array([0, 1, 0], np.float32), np.float32(0.0))

        quats = build_absolute_quaternions(angles, self.rc)
        rel = compute_relative_joint_angles(quats, self.rc)
        pos, quat = fk_from_angles(angles, self.rc)
        new_angles = ik.compute(
            ee_pos=pos, ee_quat=quat,
            joint_angles=rel, joint_quats=quats, dt=0.005,
        )
        delta = np.abs(np.asarray(new_angles, dtype=np.float32) - angles)
        for i, limit in enumerate(max_rad_per_iter):
            self.assertLessEqual(float(delta[i]), limit + 1e-5,
                                 msg=f"joint {i} delta {delta[i]} exceeds limit {limit}")

    def test_joint_limit_avoidance_repels_near_boundary(self):
        """Near an upper joint limit, the repulsion term should push the solver inward."""
        # Tight limits for the boom (joint 1) so we can start near the upper bound.
        joint_limits = [
            (-math.pi, math.pi),
            (-0.5, 0.2),
            (-math.pi, math.pi),
            (-math.pi, math.pi),
        ]
        cfg = make_ik_config(method="dls", joint_limits=joint_limits,
                             enable_joint_limit_avoidance=True,
                             enable_velocity_limiting=False,
                             ik_params={"k_val": 0.0, "min_singular_value": 1e-4, "lambda_val": 0.02})
        ik = IKController(cfg, self.rc, verbose=False, default_dt=0.005)

        # Zero IK task (k_val=0 kills task contribution) so only repulsion drives the delta.
        angles = np.array([0.0, 0.19, 0.0, 0.0], dtype=np.float32)  # just under 0.2 upper limit
        quats = build_absolute_quaternions(angles, self.rc)
        rel = compute_relative_joint_angles(quats, self.rc)
        pos, quat = fk_from_angles(angles, self.rc)

        ik.ee_pos_des = pos.astype(np.float32)
        from modules.quaternion_math import quat_from_axis_angle
        ik.ee_quat_des = quat_from_axis_angle(np.array([0, 1, 0], np.float32), np.float32(0.0))

        new_angles = ik.compute(
            ee_pos=pos, ee_quat=quat,
            joint_angles=rel, joint_quats=quats, dt=0.005,
        )
        # Joint 1 should be pushed downward (away from upper bound).
        self.assertLess(float(new_angles[1]), float(angles[1]),
                        msg=f"joint-limit avoidance did not push inward: {new_angles[1]} vs {angles[1]}")

    def test_frame_transform_position_still_stable_near_zero_slew(self):
        """Near zero slew, position IK should converge stably."""
        cfg = make_ik_config(method="dls",
                             enable_velocity_limiting=False,
                             ik_params={"k_val": 0.5, "min_singular_value": 1e-4, "lambda_val": 0.02})
        ik = IKController(cfg, self.rc, verbose=False, default_dt=0.005)
        start = np.array([0.0, math.radians(-45.0), math.radians(30.0), 0.0], dtype=np.float32)
        start_pos, _ = fk_from_angles(start, self.rc)
        target = start_pos + np.array([0.015, 0.0, -0.01], dtype=np.float32)
        result = simulate_ik(self.rc, ik, start, target,
                             max_iters=400, pos_tol=POSITION_TOL_M, dt=0.005)
        self.assertTrue(result["converged"],
                        msg=f"position IK did not converge: err={result['pos_error']:.4f}")

    def test_auto_detected_controllable_dofs_pose_mode(self):
        """Auto-detection includes yaw (slew=Z) and pitch (boom/arm/bucket=Y), excludes roll (no X joints)."""
        cfg = make_ik_config(method="dls", command_type="pose",
                             enable_velocity_limiting=False,
                             ik_params={"k_val": 0.5, "min_singular_value": 1e-4, "lambda_val": 0.02})
        ik = IKController(cfg, self.rc, verbose=False, default_dt=0.005)

        # Slew (Z) → yaw present; boom/arm/bucket (Y) → pitch present; no X joint → roll absent.
        self.assertIn(5, ik.controllable_dofs, msg="yaw should be auto-detected (slew is Z-axis joint)")
        self.assertIn(4, ik.controllable_dofs, msg="pitch should be auto-detected")
        self.assertNotIn(3, ik.controllable_dofs, msg="roll should be absent (no X-axis joint)")
        self.assertIn(0, ik.controllable_dofs)
        self.assertIn(1, ik.controllable_dofs)
        self.assertIn(2, ik.controllable_dofs)

    def test_condition_number_updated_each_iteration(self):
        cfg = make_ik_config(method="dls")
        ik = IKController(cfg, self.rc, verbose=False, default_dt=0.005)

        angles = np.array([0.0, math.radians(-30.0), math.radians(20.0), 0.0], dtype=np.float32)
        quats = build_absolute_quaternions(angles, self.rc)
        rel = compute_relative_joint_angles(quats, self.rc)
        pos, quat = fk_from_angles(angles, self.rc)
        ik.ee_pos_des = pos.astype(np.float32)
        from modules.quaternion_math import quat_from_axis_angle
        ik.ee_quat_des = quat_from_axis_angle(np.array([0, 1, 0], np.float32), np.float32(0.0))

        _ = ik.compute(ee_pos=pos, ee_quat=quat, joint_angles=rel, joint_quats=quats, dt=0.005)
        self.assertTrue(np.isfinite(ik.last_condition_number))
        self.assertGreater(ik.last_condition_number, 0.0)


if __name__ == "__main__":
    unittest.main()
