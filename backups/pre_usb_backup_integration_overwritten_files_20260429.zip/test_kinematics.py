"""Forward kinematics and Jacobian correctness tests.

These tests verify that the excavator's FK pipeline and Jacobian behave
the way the IK layer assumes.
"""

import math
import sys
import unittest
from pathlib import Path

import numpy as np

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.append(str(ROOT_DIR))

from modules.differential_ik import (  # noqa: E402
    compute_jacobian, compute_jacobian_from_joint_angles,
    compute_condition_number, project_to_rotation_axes, propagate_base_rotation,
)
from modules.excavator_ik_utils import (  # noqa: E402
    get_all_poses, compute_relative_joint_angles,
    canonical_joint_angles_from_imus,
)
from modules.quaternion_math import quat_from_axis_angle  # noqa: E402

from tests.common_kinematics import (  # noqa: E402
    build_absolute_quaternions,
    fk_from_angles,
    joint_positions_from_angles,
    load_robot_config,
    numerical_jacobian,
)


class ForwardKinematicsTests(unittest.TestCase):
    """FK should agree with analytically-derived excavator geometry."""

    @classmethod
    def setUpClass(cls):
        cls.rc = load_robot_config()

    def _assert_close(self, a, b, atol=1e-4, msg=None):
        a = np.asarray(a, dtype=np.float64)
        b = np.asarray(b, dtype=np.float64)
        self.assertTrue(
            np.allclose(a, b, atol=atol),
            msg=f"{msg or ''}\n  expected: {b}\n  actual  : {a}\n  diff    : {a-b}",
        )

    def test_zero_pose_geometry(self):
        """With all joints at zero the EE tip sits at the analytic forward reach."""
        angles = np.zeros(4, dtype=np.float32)
        pos, quat = fk_from_angles(angles, self.rc)

        # slew link direction is a unit vector; its x-component * slew-length adds to x.
        slew_length = float(self.rc.link_lengths[0])
        slew_dir = np.asarray(self.rc.link_directions[0], dtype=np.float64)
        base_x = float(self.rc.origin_offset[0]) + slew_length * slew_dir[0]
        base_z = float(self.rc.origin_offset[2]) + slew_length * slew_dir[2]

        expected_x = base_x + float(self.rc.link_lengths[1] + self.rc.link_lengths[2] + self.rc.link_lengths[3])
        expected_y = 0.0
        expected_z = base_z + float(self.rc.ee_offset[2])

        self._assert_close(pos, [expected_x, expected_y, expected_z], atol=2e-4,
                           msg="zero-pose EE position")

        # Orientation at zero pose is identity.
        self._assert_close(quat, [1.0, 0.0, 0.0, 0.0], atol=1e-6,
                           msg="zero-pose EE orientation")

    def test_pure_slew_rotates_ee_around_z(self):
        """A pure slew rotation moves the EE on a circle at constant radius and z."""
        angles0 = np.zeros(4, dtype=np.float32)
        pos0, _ = fk_from_angles(angles0, self.rc)
        r0 = math.hypot(float(pos0[0]), float(pos0[1]))
        z0 = float(pos0[2])

        for deg in (30, 60, 90, -45, -135, 170):
            angles = np.array([math.radians(deg), 0.0, 0.0, 0.0], dtype=np.float32)
            pos, _ = fk_from_angles(angles, self.rc)
            r = math.hypot(float(pos[0]), float(pos[1]))
            self.assertAlmostEqual(r, r0, delta=3e-4,
                                   msg=f"slew {deg} changed radius from {r0:.4f} to {r:.4f}")
            self.assertAlmostEqual(float(pos[2]), z0, delta=3e-4,
                                   msg=f"slew {deg} changed z from {z0:.4f} to {pos[2]:.4f}")
            yaw = math.degrees(math.atan2(float(pos[1]), float(pos[0])))
            # Wrap both to [-180, 180] and compare
            wrap = lambda a: (a + 180.0) % 360.0 - 180.0
            self.assertAlmostEqual(wrap(yaw), wrap(deg), delta=0.2,
                                   msg=f"slew {deg} yields yaw {yaw}")

    def test_boom_pitch_lifts_ee_vertically(self):
        """At zero slew, a positive boom relative angle raises the EE in +Z only."""
        angles = np.array([0.0, math.radians(30.0), 0.0, 0.0], dtype=np.float32)
        pos, _ = fk_from_angles(angles, self.rc)

        # Y component should still be zero because slew is zero.
        self.assertAlmostEqual(float(pos[1]), 0.0, delta=1e-4)

    def test_get_joint_positions_matches_forward_walk(self):
        """`get_joint_positions` should equal a direct walk along the link chain."""
        angles = np.array([0.2, -0.3, 0.4, -0.1], dtype=np.float32)
        jp = joint_positions_from_angles(angles, self.rc)
        self.assertEqual(jp.shape, (4, 3))

        # Last joint position + rotated ee_offset should equal FK output.
        ee_pos, ee_quat = fk_from_angles(angles, self.rc)
        last = np.asarray(jp[-1], dtype=np.float64)
        from modules.quaternion_math import quat_rotate_vector

        ee_from_chain = last + np.asarray(
            quat_rotate_vector(ee_quat, self.rc.ee_offset), dtype=np.float64
        )
        self.assertTrue(np.allclose(ee_from_chain, np.asarray(ee_pos, dtype=np.float64), atol=2e-4))

    def test_get_all_poses_returns_consistent_bundle(self):
        angles = np.array([0.5, -0.4, 0.2, -0.3], dtype=np.float32)
        quats = build_absolute_quaternions(angles, self.rc)
        jp, jo, ee_p, ee_o = get_all_poses(quats, self.rc)

        self.assertEqual(jp.shape, (4, 3))
        self.assertEqual(jo.shape, (4, 4))
        self.assertEqual(ee_p.shape, (3,))
        self.assertEqual(ee_o.shape, (4,))

        # EE orientation is the last joint orientation.
        self.assertTrue(np.allclose(jo[-1], ee_o, atol=1e-5))

    def test_compute_relative_joint_angles_recovers_inputs(self):
        """Absolute -> relative decomposition should recover the original angles."""
        for trial in range(5):
            rng = np.random.default_rng(1234 + trial)
            slew = float(rng.uniform(-1.0, 1.0))
            boom = float(rng.uniform(-0.8, 0.4))
            arm = float(rng.uniform(-0.4, 1.2))
            bucket = float(rng.uniform(-1.5, 0.6))

            angles = np.array([slew, boom, arm, bucket], dtype=np.float32)
            quats = build_absolute_quaternions(angles, self.rc)

            recovered = np.asarray(
                compute_relative_joint_angles(quats, self.rc), dtype=np.float64
            )
            self.assertTrue(
                np.allclose(recovered, angles.astype(np.float64), atol=5e-4),
                msg=f"trial {trial}: {recovered} vs {angles}",
            )

    def test_four_imu_canonical_extraction_recovers_inputs(self):
        """Four absolute IMU quats should reduce to one canonical joint vector."""
        for deg in range(-180, 181, 30):
            angles = np.array([math.radians(deg), -0.45, 0.35, -0.2], dtype=np.float32)
            imu_quats = build_absolute_quaternions(angles, self.rc)
            recovered = canonical_joint_angles_from_imus(imu_quats, self.rc)
            diff = np.asarray(recovered - angles, dtype=np.float64)
            diff[0] = math.atan2(math.sin(diff[0]), math.cos(diff[0]))
            self.assertTrue(
                np.all(np.abs(diff) < 6e-4),
                msg=f"yaw {deg}: recovered {recovered} vs {angles}",
            )

    def test_yaw_average_handles_quaternion_sign_flip_at_wrap(self):
        angles = np.array([math.radians(179.0), -0.45, 0.35, -0.2], dtype=np.float32)
        imu_quats = build_absolute_quaternions(angles, self.rc)
        imu_quats[2] *= -1.0  # Same physical orientation, opposite quaternion hemisphere.
        recovered = canonical_joint_angles_from_imus(imu_quats, self.rc)
        self.assertAlmostEqual(float(recovered[0]), float(angles[0]), delta=2e-3)


class BasePropagationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rc = load_robot_config()

    def test_project_to_rotation_axes_preserves_pure_y(self):
        """A pure Y rotation fed to project_to_rotation_axes is unchanged."""
        for ang in (-0.6, -0.1, 0.3, 0.9):
            q = quat_from_axis_angle(np.array([0.0, 1.0, 0.0], dtype=np.float32), np.float32(ang))
            out = project_to_rotation_axes(
                np.asarray([q]), np.asarray([[0.0, 1.0, 0.0]], dtype=np.float32)
            )
            self.assertTrue(
                np.allclose(out[0], q, atol=1e-5),
                msg=f"projection changed pure Y quat at {ang}: {out[0]} vs {q}",
            )

    def test_propagate_base_rotation_identity_on_zero_base(self):
        """With the base at identity, propagation leaves downstream unchanged."""
        idq = np.array([1.0, 0.0, 0.0, 0.0], dtype=np.float32)
        boom = quat_from_axis_angle(np.array([0.0, 1.0, 0.0], dtype=np.float32), np.float32(0.3))
        arm = quat_from_axis_angle(np.array([0.0, 1.0, 0.0], dtype=np.float32), np.float32(-0.2))
        bucket = quat_from_axis_angle(np.array([0.0, 1.0, 0.0], dtype=np.float32), np.float32(0.1))

        quats = np.array([idq, boom, arm, bucket], dtype=np.float32)
        out = propagate_base_rotation(quats, self.rc)
        self.assertTrue(np.allclose(out[1], boom, atol=1e-5))
        self.assertTrue(np.allclose(out[2], arm, atol=1e-5))
        self.assertTrue(np.allclose(out[3], bucket, atol=1e-5))


class JacobianSanityTests(unittest.TestCase):
    """Compare the analytic position Jacobian against a numerical one."""

    @classmethod
    def setUpClass(cls):
        cls.rc = load_robot_config()

    def _compare(self, angles, atol):
        angles = np.asarray(angles, dtype=np.float32)
        quats = build_absolute_quaternions(angles, self.rc)
        j_ana = np.asarray(compute_jacobian(quats, self.rc))[:3]
        j_num = numerical_jacobian(angles, self.rc)
        return j_ana, j_num, float(np.max(np.abs(j_ana - j_num)))

    def test_jacobian_matches_numerical_across_full_slew_rotation(self):
        arm_poses = (
            [-0.4, 0.3, -0.1],
            [0.2, -0.4, 0.2],
            [-0.6, 0.8, -0.3],
            [0.0, 0.0, 0.0],
        )
        for deg in range(-180, 181, 30):
            for arm_pose in arm_poses:
                angles = [math.radians(deg), *arm_pose]
                j_ana, j_num, diff = self._compare(angles, atol=2e-3)
                self.assertLess(
                    diff,
                    2e-3,
                    msg=f"yaw {deg} Jacobian mismatch {diff} at {angles}\nana={j_ana}\nnum={j_num}",
                )

    def test_jacobian_from_joint_angles_matches_quaternion_wrapper(self):
        for deg in range(-180, 181, 45):
            angles = np.array([math.radians(deg), -0.4, 0.3, -0.1], dtype=np.float32)
            j_ana, j_num, diff = self._compare(angles, atol=2e-3)
            j_angles = np.asarray(compute_jacobian_from_joint_angles(angles, self.rc))[:3]
            self.assertTrue(np.allclose(j_ana, j_angles, atol=1e-6))
            self.assertLess(diff, 2e-3)

    def test_condition_number_finite_away_from_singularity(self):
        angles = np.array([0.1, -0.4, 0.3, -0.1], dtype=np.float32)
        quats = build_absolute_quaternions(angles, self.rc)
        J = np.asarray(compute_jacobian(quats, self.rc))
        cond = compute_condition_number(J)
        self.assertTrue(np.isfinite(cond))
        self.assertGreater(cond, 1.0)

    def test_singularity_detection_finds_bad_configs(self):
        """Fully extended (boom=arm=0) near the horizon is close to a wrist singularity."""
        angles = np.array([0.0, 0.0, 0.0, 0.0], dtype=np.float32)
        quats = build_absolute_quaternions(angles, self.rc)
        J = np.asarray(compute_jacobian(quats, self.rc))
        cond = compute_condition_number(J)
        self.assertTrue(np.isfinite(cond))


if __name__ == "__main__":
    unittest.main()
